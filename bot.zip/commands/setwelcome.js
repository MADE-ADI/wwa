const fs = require('fs');
const path = require('path');
const isAdmin = require('../helpers/isAdmin');

/**
 * Command to set custom welcome and goodbye messages for a group
 * @param {Object} sock - Socket connection
 * @param {String} chatId - Chat ID
 * @param {String} senderId - Sender ID
 * @param {String} userMessage - User message text
 * @param {String} botName - Bot name for session directory
 */
async function setWelcomeCommand(sock, chatId, senderId, userMessage, botName) {
    try {
        // Periksa apakah ini adalah grup
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: '❌ Perintah ini hanya dapat digunakan di grup.',
            });
            return;
        }

        // Periksa apakah pengirim adalah admin
        const { isSenderAdmin } = await isAdmin(sock, chatId, senderId);
        
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { 
                text: '❌ Hanya admin grup yang dapat menggunakan perintah ini.',
            });
            return;
        }

        // Tentukan direktori untuk menyimpan data welcome/goodbye
        const sessionDir = path.join(__dirname, `../bot-sessions/${botName}/group-settings`);
        if (!fs.existsSync(sessionDir)) {
            fs.mkdirSync(sessionDir, { recursive: true });
        }

        // File untuk menyimpan pengaturan grup
        const settingsFile = path.join(sessionDir, `${chatId.split('@')[0]}.json`);
        
        // Inisialisasi atau muat pengaturan grup
        let groupSettings = { welcome: '', goodbye: '', enabled: true };
        if (fs.existsSync(settingsFile)) {
            groupSettings = JSON.parse(fs.readFileSync(settingsFile, 'utf-8'));
        }

        // Tentukan jenis pesan yang akan diatur (welcome atau goodbye)
        let messageType = '';
        let newMessage = '';

        if (userMessage.startsWith('.setwelcome')) {
            messageType = 'welcome';
            newMessage = userMessage.substring(12).trim();
        } else if (userMessage.startsWith('.setgoodbye')) {
            messageType = 'goodbye';
            newMessage = userMessage.substring(12).trim();
        } else if (userMessage === '.welcomeon' || userMessage === '.welcomeoff') {
            groupSettings.enabled = userMessage === '.welcomeon';
            fs.writeFileSync(settingsFile, JSON.stringify(groupSettings, null, 2));
            
            await sock.sendMessage(chatId, { 
                text: groupSettings.enabled ? 
                    '✅ Pesan welcome dan goodbye telah diaktifkan.' : 
                    '❌ Pesan welcome dan goodbye telah dinonaktifkan.'
            });
            return;
        } else if (userMessage === '.resetwelcome') {
            groupSettings.welcome = '';
            fs.writeFileSync(settingsFile, JSON.stringify(groupSettings, null, 2));
            
            await sock.sendMessage(chatId, { 
                text: '✅ Pesan welcome telah direset ke default.'
            });
            return;
        } else if (userMessage === '.resetgoodbye') {
            groupSettings.goodbye = '';
            fs.writeFileSync(settingsFile, JSON.stringify(groupSettings, null, 2));
            
            await sock.sendMessage(chatId, { 
                text: '✅ Pesan goodbye telah direset ke default.'
            });
            return;
        }

        // Jika tidak ada pesan baru yang diberikan
        if (!newMessage) {
            await sock.sendMessage(chatId, { 
                text: `❌ Silakan berikan pesan ${messageType}!\n\n` +
                      `Contoh: .set${messageType} Selamat datang di grup kami @user!\n\n` +
                      `Variabel yang tersedia:\n` +
                      `- @user = Mention pengguna\n` +
                      `- @group = Nama grup\n` +
                      `- @desc = Deskripsi grup\n` +
                      `- @count = Jumlah anggota grup\n\n` +
                      `Perintah lain:\n` +
                      `- .welcomeon = Aktifkan pesan welcome/goodbye\n` +
                      `- .welcomeoff = Nonaktifkan pesan welcome/goodbye\n` +
                      `- .resetwelcome = Reset pesan welcome ke default\n` +
                      `- .resetgoodbye = Reset pesan goodbye ke default`
            });
            return;
        }

        // Simpan pesan baru
        groupSettings[messageType] = newMessage;
        fs.writeFileSync(settingsFile, JSON.stringify(groupSettings, null, 2));

        // Dapatkan metadata grup untuk preview
        const groupMetadata = await sock.groupMetadata(chatId);
        const groupName = groupMetadata.subject;
        const memberCount = groupMetadata.participants.length;
        const groupDesc = groupMetadata.desc || 'Tidak ada deskripsi';

        // Buat preview pesan
        let previewMessage = newMessage
            .replace(/@user/g, `@${senderId.split('@')[0]}`)
            .replace(/@group/g, groupName)
            .replace(/@desc/g, groupDesc)
            .replace(/@count/g, memberCount);

        // Kirim konfirmasi dengan preview
        await sock.sendMessage(chatId, { 
            text: `✅ Pesan ${messageType} telah diatur!\n\n*Preview:*\n\n${previewMessage}`,
            mentions: [senderId]
        });

    } catch (error) {
        console.error(`Error setting ${messageType} message:`, error);
        await sock.sendMessage(chatId, { 
            text: `❌ Error: ${error.message}`,
        });
    }
}

module.exports = setWelcomeCommand; 