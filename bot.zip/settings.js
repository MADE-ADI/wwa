const settings = {
  packname: 'Hanaby LM Pack',
  author: 'Hanaby LM',
  botName: "Hanaby BOT",
  botOwner: 'Hanaby', // Your name
  ownerNumber: '6285172051605', //Your number
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.1.0",
};

module.exports = settings;
